# Village Ground Lab

Medieval village builder + tower defence prototype (three.js). Open `index.html` in a browser. See `CLAUDE.md` for full design and technical notes.
